module.exports = {
    "RECIPE_EN_US" : {
        "agile": "A snow golem can be created by placing a pumpkin on top of  two snow blocks on the ground."
    }
};
